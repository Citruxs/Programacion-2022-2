public class Felino extends Animal {
    public Felino(String raza){
        super(raza);
    }
}
