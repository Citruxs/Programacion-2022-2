public interface Comunicable{

    public abstract void hablar();
   }
