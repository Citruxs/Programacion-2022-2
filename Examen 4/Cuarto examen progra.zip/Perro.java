public class Perro extends Canino {
    public Perro(String raza){
        super(raza);
    }
}
