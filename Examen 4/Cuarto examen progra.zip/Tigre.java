public class Tigre extends Felino {
    public Tigre(String raza){
        super(raza);
    }
}
