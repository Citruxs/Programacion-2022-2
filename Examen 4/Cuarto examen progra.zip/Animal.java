public class Animal implements Comunicable{
    protected String raza; 
    
    public Animal(String raza){
        this.raza = raza;
    }

    @Override
    public void hablar(){
        System.out.println("Este animal puede hablar");
    }
}
