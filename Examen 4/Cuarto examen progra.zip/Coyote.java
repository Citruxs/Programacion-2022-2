public class Coyote extends Canino {
    public Coyote(String raza){
        super(raza);
    }
}
