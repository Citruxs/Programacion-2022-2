public class Canino extends Animal {
    public Canino(String raza){
        super(raza);
    }
}
