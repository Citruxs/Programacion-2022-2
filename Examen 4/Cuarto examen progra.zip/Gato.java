public class Gato extends Felino {
    public Gato(String raza){
        super(raza);
    }
}