public class Parcial4 {
    public static void main(String[] args) {
        Gato persa = new Gato("Persa");

        System.out.println(persa);
    }
}
